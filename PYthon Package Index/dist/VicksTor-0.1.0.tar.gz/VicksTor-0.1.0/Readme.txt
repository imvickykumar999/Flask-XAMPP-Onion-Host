
https://raw.githubusercontent.com/imvickykumar999/Flask-XAMPP-Onion-Host/main/Tutorial%20Files/VicksTor.py

# just add this 2 line to host flask on Tor

from HostTor import VicksTor

import VicksTor
